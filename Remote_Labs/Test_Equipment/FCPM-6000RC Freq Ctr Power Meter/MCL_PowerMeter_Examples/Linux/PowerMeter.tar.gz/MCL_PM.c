#include <hid.h>
#include <stdio.h>
#include <string.h>
#include <usb.h>

#define VENDOR_ID  0x20ce   // MiniCircuits Vendor ID
#define PRODUCT_ID 0x0011   // MiniCircuits HID Power Sensoe Product ID
#define PATHLEN  2
#define SEND_PACKET_LEN 64

 HIDInterface* hid;
 hid_return ret;
 struct usb_device *usb_dev;
 struct usb_dev_handle *usb_handle;
 char buffer[80], kdname[80];


const int PATH_IN[PATHLEN] = { 0x00010005, 0x00010033 };
char  PACKET[SEND_PACKET_LEN];  



bool match_serial_number(struct usb_dev_handle* usbdev, void* custom, unsigned int len)
{
  bool ret;
  char* buffer = (char*)malloc(len);
  usb_get_string_simple(usbdev, usb_device(usbdev)->descriptor.iSerialNumber,
      buffer, len);
  ret = strncmp(buffer, (char*)custom, len) == 0;
  free(buffer);
  return ret;
}


static struct usb_device *device_init(void)
{
    struct usb_bus *usb_bus;
    struct usb_device *dev;
    usb_init();
    usb_find_busses();
    usb_find_devices();
    for (usb_bus = usb_busses; usb_bus; usb_bus = usb_bus->next)
    {
        for (dev = usb_bus->devices; dev; dev = dev->next)
        {
            if ((dev->descriptor.idVendor == VENDOR_ID) &&
                (dev->descriptor.idProduct == PRODUCT_ID)) {		
		return dev;
	    }
        }
    }
    return NULL;
}
void Get_PN (char* PNstr)  
{
        int i;
        char  PACKETreceive[SEND_PACKET_LEN];
        PACKET[0]=104;  //     PN code
        ret = hid_interrupt_write(hid, 0x01, PACKET, SEND_PACKET_LEN,1000);
 	if (ret != HID_RET_SUCCESS) {
		fprintf(stderr, "hid_interrupt_write failed with return code %d\n", ret);
	}
        ret = hid_interrupt_read(hid, 0x01, PACKETreceive, SEND_PACKET_LEN,1000);
        if (ret == HID_RET_SUCCESS) {
              strncpy(PNstr,PACKETreceive,SEND_PACKET_LEN); 
              for (i=0;PNstr[i+1]!='\0';i++) {
                       PNstr[i]=PNstr[i+1];
                                              }  
              PNstr[i]='\0';
           } 
       	if (ret != HID_RET_SUCCESS) {
		fprintf(stderr, "hid_interrupt_read failed with return code %d\n", ret);	}
  
}
void Get_SN (char* SNstr)
{
       int i;
       char  PACKETreceive[SEND_PACKET_LEN];
       PACKET[0]=105;  //     SN Code
        ret = hid_interrupt_write(hid, 0x01, PACKET, SEND_PACKET_LEN,1000);
 	if (ret != HID_RET_SUCCESS) {
		fprintf(stderr, "hid_interrupt_write failed with return code %d\n", ret);
	}
        ret = hid_interrupt_read(hid, 0x01, PACKETreceive, SEND_PACKET_LEN,1000);
        if (ret == HID_RET_SUCCESS) {
               strncpy(SNstr,PACKETreceive,SEND_PACKET_LEN);
             for (i=0;SNstr[i+1]!='\0';i++) {
                       SNstr[i]=SNstr[i+1];
                                              }  
             SNstr[i]='\0';
           }
	if (ret != HID_RET_SUCCESS) {
		fprintf(stderr, "hid_interrupt_read failed with return code %d\n", ret);	}

        
}
void Set_Faster_mode()
{
char  PACKETreceive[SEND_PACKET_LEN];

      PACKET[0]=15; PACKET[1]=1; //    Faster Mode:  1st byte=15 ,2nd byte =1
        ret = hid_interrupt_write(hid, 0x01, PACKET, SEND_PACKET_LEN,1000);
 	if (ret != HID_RET_SUCCESS) {
		fprintf(stderr, "hid_interrupt_write failed with return code %d\n", ret);
	}
        ret = hid_interrupt_read(hid, 0x01, PACKETreceive, SEND_PACKET_LEN,1000);

}

void Set_LowNoise_Mode()
{
char  PACKETreceive[SEND_PACKET_LEN];

      PACKET[0]=15; PACKET[1]=0; //    Low Noise Mode:  1st byte=15 ,2nd byte =0
        ret = hid_interrupt_write(hid, 0x01, PACKET, SEND_PACKET_LEN,1000);
 	if (ret != HID_RET_SUCCESS) {
		fprintf(stderr, "hid_interrupt_write failed with return code %d\n", ret);
	}
        ret = hid_interrupt_read(hid, 0x01, PACKETreceive, SEND_PACKET_LEN,1000);

}

void Get_Power (unsigned char **Freq1,char* Pwr)
//  Freq1 = input frequency ,  Pwr = output Power
{
        int i;
        char  PACKETreceive[SEND_PACKET_LEN];
	// Writing / Reading From USB 
        PACKET[0]=102;          // 102 = code to get power
        PACKET[1]= atoi(Freq1[1])/256;
        PACKET[2]= atoi(Freq1[1])%256;
        //  Frequency   to Hex   Packet[1]=hi  packet[2]=lo
        ret = hid_interrupt_write(hid, 0x01, PACKET, SEND_PACKET_LEN,1000);
 	if (ret != HID_RET_SUCCESS) {
		fprintf(stderr, "hid_interrupt_write failed with return code %d\n", ret);
	}
        ret = hid_interrupt_read(hid, 0x01, PACKETreceive, SEND_PACKET_LEN,1000);
        //  Read packet  Packetreceive[0]=102 get power  Packetreceive[1]-Packetreceive[6] Ascii of Power ex: -10.05 

        if (ret == HID_RET_SUCCESS)        
        {  
             strncpy(Pwr,PACKETreceive,SEND_PACKET_LEN);  
            for (i=0;Pwr[i+1]!='\0';i++) {
                       Pwr[i]=Pwr[i+1];
                                          }           
            Pwr[i]='\0';
        }

 	if (ret != HID_RET_SUCCESS) {
		fprintf(stderr, "hid_interrupt_read failed with return code %d\n", ret);	}
 
}

int main( int argc, unsigned char **argv)
{
  usb_dev = device_init();

  if (usb_dev == NULL)
  {
      fprintf(stderr, "Device not found!\n");
      exit(-1);
  }  
  if (usb_dev != NULL) 
  {
      usb_handle = usb_open(usb_dev);
      int drstatus = usb_get_driver_np(usb_handle, 0, kdname, sizeof(kdname));
      if (kdname != NULL && strlen(kdname) > 0) {
	  usb_detach_kernel_driver_np(usb_handle, 0);
      }
  }
  usb_reset(usb_handle);
  usb_close(usb_handle);
  HIDInterfaceMatcher matcher = { VENDOR_ID, PRODUCT_ID, NULL, NULL, 0 };  
  ret = hid_init();
  if (ret != HID_RET_SUCCESS) {
    fprintf(stderr, "hid_init failed with return code %d\n", ret);
    return 1;
  }
  hid = hid_new_HIDInterface();
  if (hid == 0) {
    fprintf(stderr, "hid_new_HIDInterface() failed, out of memory?\n");
    return 1;
  }
  
  ret = hid_force_open(hid, 0, &matcher, 3);
  if (ret != HID_RET_SUCCESS) {
    fprintf(stderr, "hid_force_open failed with return code %d\n", ret);
    return 1;
  }
  
//////////////   Read  Power    ///////////////////////////////////////////////////////////

char  PNreceive[SEND_PACKET_LEN];
char  SNreceive[SEND_PACKET_LEN];
char  RFpower[SEND_PACKET_LEN];
int StrLen1;

 Get_PN(PNreceive);
 fprintf(stderr," PN=  %s .\n",PNreceive);

 Get_SN(SNreceive);
 fprintf(stderr," SN=  %s .\n",SNreceive);

 Set_Faster_mode; //   Set_LowNoise_Mode

 Get_Power(argv,RFpower);
 fprintf(stderr," Power=  %s dBm.\n",RFpower);   

//////////////////////////////////////////////////////////////////////////////////////////////
 
  ret = hid_close(hid);
  if (ret != HID_RET_SUCCESS) {
    fprintf(stderr, "hid_close failed with return code %d\n", ret);
    return 1;
  }

  hid_delete_HIDInterface(&hid);

  ret = hid_cleanup();
  if (ret != HID_RET_SUCCESS) {
    fprintf(stderr, "hid_cleanup failed with return code %d\n", ret);
    return 1;
  }

  return 0;
}

